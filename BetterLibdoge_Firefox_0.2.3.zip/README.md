betterlibdoge (firefox)
==============

![License](https://img.shields.io/badge/license-WTFPL-blue)
![Version](https://img.shields.io/badge/version-0.2.3-brightgreen.svg)

license
-------------
Doge is licensed under the [WTFPL](http://www.wtfpl.net/about/) license because, well, Doge *willed* it so. 

Much freedom.
Do whatever you want with Doge!

what is this?
---------------

This is a modification of the [libdoge chrome extension](https://chromewebstore.google.com/detail/libdoge/ifbchccfedjkkhlnffjckaghjdpchhmo?hl=en). It, generally, is a port of it to *Firefox*, with some changes.

Added:

1. some modifications to the dataminer. it now saves everything it mines to it's local storage. no, we don't save any of your data, it's all local


This doge lives [here](https://github.com/manOnWebs/BetterLibdoge).
or, the original [here](https://github.com/ljalonen/libdoge).

How to install 
---------------

1. download or clone the repository 
with git (must have git installed on your system): ```git clone https://github.com/manOnWebs/BetterLibdoge```
or, go to [releases](https://github.com/manOnWebs/BetterLibdoge/releases) to get the latest version

2. zip up the BetterLibdoge folder's contents

3. open any Firefox web browser

4. go to about:addons

5. click "load extension from file"

6. go to the zip's location

7. select it

8. doge should now invade your browser\


OR


install it from [Firefox Addons](https://addons.mozilla.org/en-US/firefox/addon/betterlibdoge/)