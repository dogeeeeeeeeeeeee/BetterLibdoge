// js/main.js
import './animation.js';
import './controller.js';
import './dataminer.js';
import './doge.js';
import './keybinds.js';
import './util.js';
